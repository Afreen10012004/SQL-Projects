import sys
sys.path.append(r"C:\Users\parve\Documents\HospitalManagement")

from Dao.IHospitalService import IHospitalService
from util.DBConnection import DBConnection
from entity.Appointment import Appointment
from exception.PatientNumberNotFoundException import PatientNumberNotFoundException

class HospitalServiceImpl(IHospitalService):

    def __init__(self):
        self.conn = DBConnection.getConnection()
        self.cursor = self.conn.cursor()

    def getAppointmentByID(self, appointmentID):
        query = "SELECT * FROM Appointment WHERE AppointmentID = ?"
        self.cursor.execute(query, appointmentID)
        row = self.cursor.fetchone()
        if row:
            return Appointment(*row)
        return None

    def getAppointmentsForPatient(self, patientID):
        query = "SELECT * FROM Appointment WHERE PatientID = ?"
        self.cursor.execute(query, patientID)
        rows = self.cursor.fetchall()
        if not rows:
            raise PatientNumberNotFoundException("Patient ID " + str(patientID) + " not found.")
        appointments = []
        for row in rows:
            appointments.append(Appointment(*row))
        return appointments

    def getAppointmentsForDoctor(self, doctorID):
        query = "SELECT * FROM Appointment WHERE DoctorID = ?"
        self.cursor.execute(query, doctorID)
        rows = self.cursor.fetchall()
        appointments = []
        for row in rows:
            appointments.append(Appointment(*row))
        return appointments

    def scheduleAppointment(self, appointment):
        query = "INSERT INTO Appointment (AppointmentID, PatientID, DoctorID, AppointmentDate, Description) VALUES (?, ?, ?, ?, ?)"
        try:
            self.cursor.execute(query,
                appointment.getAppointmentID(),
                appointment.getPatientID(),
                appointment.getDoctorID(),
                appointment.getAppointmentDate(),
                appointment.getDescription()
            )
            self.conn.commit()
            return True
        except Exception as e:
            print("Error scheduling appointment:", e)
            return False

    def updateAppointment(self, appointment):
        query = "UPDATE Appointment SET PatientID = ?, DoctorID = ?, AppointmentDate = ?, Description = ? WHERE AppointmentID = ?"
        try:
            self.cursor.execute(query,
                appointment.getPatientID(),
                appointment.getDoctorID(),
                appointment.getAppointmentDate(),
                appointment.getDescription(),
                appointment.getAppointmentID()
            )
            self.conn.commit()
            return True
        except Exception as e:
            print("Error updating appointment:", e)
            return False

    def cancelAppointment(self, appointmentID):
        query = "DELETE FROM Appointment WHERE AppointmentID = ?"
        try:
            self.cursor.execute(query, appointmentID)
            self.conn.commit()
            return True
        except Exception as e:
            print("Error canceling appointment:", e)
            return False
