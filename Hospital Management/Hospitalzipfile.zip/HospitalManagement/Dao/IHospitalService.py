from abc import ABC, abstractmethod
from typing import List
from entity.Appointment import Appointment 

class IHospitalService(ABC):

    @abstractmethod
    def getAppointmentByID(self, appointmentID: int) -> Appointment:
        pass

    @abstractmethod
    def getAppointmentsForPatient(self, patientID: int) -> List[Appointment]:
        pass

    @abstractmethod
    def getAppointmentsForDoctor(self, doctorID: int) -> List[Appointment]:
        pass

    @abstractmethod
    def scheduleAppointment(self, appointment: Appointment) -> bool:
        pass

    @abstractmethod
    def updateAppointment(self, appointment: Appointment) -> bool:
        pass

    @abstractmethod
    def cancelAppointment(self, appointmentID: int) -> bool:
        pass
