class Patient:
    def __init__(self, PatientID=None, FirstName=None, LastName=None, DateOfBirth=None, Gender=None, ContactNumber=None, Address=None):
        self.__PatientID = PatientID
        self.__FirstName = FirstName
        self.__LastName = LastName
        self.__DateOfBirth = DateOfBirth
        self.__Gender = Gender
        self.__ContactNumber = ContactNumber
        self.__Address = Address

   
    def getPatientID(self): 
        return self.__PatientID
    def setPatientID(self, value): 
        self.__PatientID = value

    def getFirstName(self): 
        return self.__FirstName
    def setFirstName(self, value): 
        self.__FirstName = value

    def getLastName(self): 
        return self.__LastName
    def setLastName(self, value): 
        self.__LastName = value

    def getDateOfBirth(self): 
        return self.__DateOfBirth
    def setDateOfBirth(self, value): 
        self.__DateOfBirth = value

    def getGender(self): 
        return self.__Gender
    def setGender(self, value): 
        self.__Gender = value

    def getContactNumber(self): 
        return self.__ContactNumber
    def setContactNumber(self, value): 
        self.__ContactNumber = value

    def getAddress(self): 
        return self.__Address
    def setAddress(self, value): 
        self.__Address = value

    def __str__(self):
        return (f"PatientID: {self.__PatientID}, FirstName: {self.__FirstName}, LastName: {self.__LastName}, "
                f"DateOfBirth: {self.__DateOfBirth}, Gender: {self.__Gender}, "
                f"ContactNumber: {self.__ContactNumber}, Address: {self.__Address}")
