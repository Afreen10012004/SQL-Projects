class Doctor:
    def __init__(self, DoctorID=None, FirstName=None, LastName=None, Specialization=None, ContactNumber=None):
        self.__DoctorID = DoctorID
        self.__FirstName = FirstName
        self.__LastName = LastName
        self.__Specialization = Specialization
        self.__ContactNumber = ContactNumber

  
    def getDoctorID(self): 
        return self.__DoctorID
    def setDoctorID(self, value): 
        self.__DoctorID = value

    def getFirstName(self): 
        return self.__FirstName
    def setFirstName(self, value): 
        self.__FirstName = value

    def getLastName(self): 
        return self.__LastName
    def setLastName(self, value): 
        self.__LastName = value

    def getSpecialization(self): 
        return self.__Specialization
    def setSpecialization(self, value): 
        self.__Specialization = value

    def getContactNumber(self): 
        return self.__ContactNumber
    def setContactNumber(self, value): 
        self.__ContactNumber = value

    def __str__(self):
        return (f"DoctorID: {self.__DoctorID}, FirstName: {self.__FirstName}, LastName: {self.__LastName}, "
                f"Specialization: {self.__Specialization}, ContactNumber: {self.__ContactNumber}")
