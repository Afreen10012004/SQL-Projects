class Appointment:
    def __init__(self, AppointmentID=None, PatientID=None, DoctorID=None, AppointmentDate=None, Description=None):
        self.__AppointmentID = AppointmentID
        self.__PatientID = PatientID
        self.__DoctorID = DoctorID
        self.__AppointmentDate = AppointmentDate
        self.__Description = Description

  
    def getAppointmentID(self): 
        return self.__AppointmentID
    def setAppointmentID(self, value): 
        self.__AppointmentID = value

    def getPatientID(self):
        return self.__PatientID
    def setPatientID(self, value): 
        self.__PatientID = value

    def getDoctorID(self): 
        return self.__DoctorID
    def setDoctorID(self, value): 
        self.__DoctorID = value

    def getAppointmentDate(self): 
        return self.__AppointmentDate
    def setAppointmentDate(self, value): 
        self.__AppointmentDate = value

    def getDescription(self): 
        return self.__Description
    def setDescription(self, value): 
        self.__Description = value

    def __str__(self):
        return (f"AppointmentID: {self.__AppointmentID}, PatientID: {self.__PatientID}, DoctorID: {self.__DoctorID}, "
                f"AppointmentDate: {self.__AppointmentDate}, Description: {self.__Description}")
