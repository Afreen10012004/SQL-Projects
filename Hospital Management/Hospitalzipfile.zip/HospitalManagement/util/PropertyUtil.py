import sys
sys.path.append(r"C:\Users\parve\Documents\HospitalManagement")

import pyodbc

driver_name='SQL Server'
server='localhost\\SQLEXPRESS'
database='HospitalManagement'
username='Afreen'
password='abc'

class PropertyUtil:
    @staticmethod
    def get_property_string():
        connection_string=f'Driver={driver_name};Server={server};Database={database};Trusted_connection=yes;'
        return connection_string
