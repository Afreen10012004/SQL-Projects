import pyodbc

import sys
sys.path.append(r"C:\Users\parve\Documents\HospitalManagement")

from util.PropertyUtil import PropertyUtil

class DBConnection:
    @staticmethod
    def getConnection():
        connection_string=PropertyUtil.get_property_string()
        return pyodbc.connect(connection_string)


