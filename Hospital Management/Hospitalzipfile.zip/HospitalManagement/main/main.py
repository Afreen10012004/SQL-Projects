import sys
sys.path.append(r"C:\Users\parve\Documents\HospitalManagement")

from Dao.HospitalServiceImpl import HospitalServiceImpl
from entity.Appointment import Appointment

def main():
    service = HospitalServiceImpl()

    
    appointment = Appointment(
        7001,  
        1,     
        1,     
        '2025-09-01',
        'Routine health checkup'
    )

    result = service.scheduleAppointment(appointment)
    if result:
        print("Appointment scheduled successfully.")
    else:
        print("Failed to schedule appointment.")

    
    print("\n--- Appointments for Patient ID 1 ---")
    appointments = service.getAppointmentsForPatient(1)
    for a in appointments:
        print(a)

if __name__ == "__main__":
    main()
