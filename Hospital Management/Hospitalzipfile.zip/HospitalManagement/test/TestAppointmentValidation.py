import sys
sys.path.append(r"C:\Users\parve\Documents\HospitalManagement")

import unittest
from entity.Appointment import Appointment

class TestAppointmentValidation(unittest.TestCase):

    def test_valid_appointment_fields(self):
       
        appt = Appointment(111, 1, 2, "2025-07-01", "General checkup")

        self.assertTrue(appt.getDescription() != "", "Description should not be empty")

if __name__ == "__main__":
    unittest.main()
