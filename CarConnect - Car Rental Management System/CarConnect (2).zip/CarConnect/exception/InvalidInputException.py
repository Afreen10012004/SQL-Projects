class InvalidInputException(Exception):
    def __init__(self, message="Invalid or missing input"):
        super().__init__(message)
