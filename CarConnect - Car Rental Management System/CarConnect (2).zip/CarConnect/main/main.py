import sys
sys.path.append(r"C:\Users\parve\Documents\CarConnect")  

from Dao.AuthenticationService import AuthenticationService
from Dao.AdminService import AdminService
from Dao.CustomerService import CustomerService
from Dao.ReservationService import ReservationService
from Dao.VehicleService import VehicleService
from entity.Admin import Admin
from entity.Customer import Customer
from entity.Reservation import Reservation
from entity.Vehicle import Vehicle

authentication_service = AuthenticationService()
admin_service = AdminService()
customer_service = CustomerService()
vehicle_service = VehicleService()
reservation_service = ReservationService()

def handle_customer_actions(customer):
    while True:
        print("\n--- Customer Action Menu ---")
        print("1. Create Reservation")
        print("2. Update Reservation")
        print("3. Cancel Reservation")
        print("4. Update Customer Information")
        print("5. Get Available Vehicles")
        print("6. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            reservationID = int(input("Enter Reservation ID: "))
            vehicleID = int(input("Enter Vehicle ID: "))
            startDate = input("Enter Start Date (YYYY-MM-DD): ")
            endDate = input("Enter End Date (YYYY-MM-DD): ")
            totalCost = float(input("Enter Total Cost: "))
            status = input("Enter Status: ")
            reservation = Reservation(reservationID, customer.CustomerID, vehicleID, startDate, endDate, totalCost, status)
            reservation_service.create_reservation(reservation)
            print("Reservation created successfully.")

        elif choice == '2':
            reservationID = int(input("Enter Reservation ID to update: "))
            vehicleID = int(input("Enter new Vehicle ID: "))
            startDate = input("Enter new Start Date (YYYY-MM-DD): ")
            endDate = input("Enter new End Date (YYYY-MM-DD): ")
            totalCost = float(input("Enter new Total Cost: "))
            status = input("Enter new Status: ")
            reservation = Reservation(reservationID, customer.CustomerID, vehicleID, startDate, endDate, totalCost, status)
            reservation_service.update_reservation(reservation)
            print("Reservation updated.")

        elif choice == '3':
            res_id = int(input("Enter Reservation ID to cancel: "))
            reservation_service.cancel_reservation(res_id)
            print("Reservation cancelled.")

        elif choice == '4':
            print("Updating Customer Information")
            firstName = input("First Name: ")
            lastName = input("Last Name: ")
            email = input("Email: ")
            phoneNumber = input("Phone Number: ")
            address = input("Address: ")
            username = input("Username: ")
            password = input("Password: ")
            registrationDate = input("Registration Date (YYYY-MM-DD): ")

            updated_customer = Customer(customer.CustomerID, firstName, lastName, email, phoneNumber, address,
                                        username, password, registrationDate)
            customer_service.update_customer(updated_customer)
            print("Customer information updated.")

        elif choice == '5':
            available = vehicle_service.get_available_vehicles()
            for v in available:
                print(vars(v))

        elif choice == '6':
            break
        else:
            print("Invalid choice.")

def customer_workflow():
    while True:
        print("\n--- Customer Workflow ---")
        print("1. Customer Registration")
        print("2. Customer Login")
        print("3. Back")

        choice = input("Enter your choice: ")

        if choice == '1':
            print("Customer Registration")
            CustomerID = int(input("Customer ID: "))
            FirstName = input("First Name: ")
            LastName = input("Last Name: ")
            Email = input("Email: ")
            PhoneNumber = input("Phone Number: ")
            Address = input("Address: ")
            UserName = input("Username: ")
            Password = input("Password: ")
            RegistrationDate = input("Registration Date (YYYY-MM-DD): ")
            new_customer = Customer(CustomerID, FirstName, LastName, Email, PhoneNumber, Address,
                                    UserName, Password, RegistrationDate)
            customer_service.register_customer(new_customer)
            print("Registration successful.")

        elif choice == '2':
            username = input("Username: ")
            password = input("Password: ")
            if authentication_service.authenticate_customer(username, password):
                print("Login successful.")
                customer = customer_service.get_customer_by_username(username)
                handle_customer_actions(customer)
            else:
                print("Login failed. Incorrect credentials.")

        elif choice == '3':
            break
        else:
            print("Invalid choice.")

def handle_admin_actions():
    while True:
        print("\n--- Admin Action Menu ---")
        print("1. Get Admin by ID")
        print("2. Update Admin")
        print("3. Remove Admin")
        print("4. Add Vehicle")
        print("5. Update Vehicle")
        print("6. Remove Vehicle")
        print("7. View All Reservations")
        print("8. View Available Vehicles")
        print("9. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            adminID = int(input("Enter Admin ID: "))
            print(admin_service.get_admin_by_id(adminID))

        elif choice == '2':
            adminID = int(input("Admin ID: "))
            firstName = input("First Name: ")
            lastName = input("Last Name: ")
            email = input("Email: ")
            phoneNumber = input("Phone Number: ")
            username = input("Username: ")
            password = input("Password: ")
            role = input("Role: ")
            joinDate = input("Join Date (YYYY-MM-DD): ")
            admin = Admin(adminID, firstName, lastName, email, phoneNumber, username, password, role, joinDate)
            admin_service.update_admin(admin)
            print("Admin updated.")

        elif choice == '3':
            adminID = int(input("Admin ID to remove: "))
            admin_service.delete_admin(adminID)
            print("Admin removed.")

        elif choice == '4':
            VehicleID = int(input("Vehicle ID: "))
            Model = input("Model: ")
            Make = input("Make: ")
            Year = int(input("Year: "))
            Color = input("Color: ")
            RegistrationNumber = input("Registration Number: ")
            Availability = input("Available (Yes/No): ").lower() == "yes"
            DailyRate = float(input("Daily Rate: "))
            vehicle = Vehicle(VehicleID, Model, Make, Year, Color, RegistrationNumber, Availability, DailyRate)
            vehicle_service.add_vehicle(vehicle)
            print("Vehicle added.")

        elif choice == '5':
            VehicleID = int(input("Vehicle ID to update: "))
            Model = input("Model: ")
            Make = input("Make: ")
            Year = int(input("Year: "))
            Color = input("Color: ")
            RegistrationNumber = input("Registration Number: ")
            Availability = input("Available (Yes/No): ").lower() == "yes"
            DailyRate = float(input("Daily Rate: "))
            vehicle = Vehicle(VehicleID, Model, Make, Year, Color, RegistrationNumber, Availability, DailyRate)
            vehicle_service.update_vehicle(vehicle)
            print("Vehicle updated.")

        elif choice == '6':
            VehicleID = int(input("Vehicle ID to delete: "))
            vehicle_service.remove_vehicle(VehicleID)
            print("Vehicle deleted.")

        elif choice == '7':
            for customerID in range(1, 6):
                reservations = reservation_service.get_reservations_by_customer_id(customerID)
                for r in reservations:
                    print(vars(r))

        elif choice == '8':
            available = vehicle_service.get_available_vehicles()
            for v in available:
                print(vars(v))

        elif choice == '9':
            break
        else:
            print("Invalid choice.")

def admin_workflow():
    while True:
        print("\n--- Admin Workflow ---")
        print("1. Admin Registration")
        print("2. Admin Login")
        print("3. Back")

        choice = input("Enter your choice: ")

        if choice == '1':
            AdminID = int(input("Admin ID: "))
            FirstName = input("First Name: ")
            LastName = input("Last Name: ")
            Email = input("Email: ")
            PhoneNumber = input("Phone Number: ")
            UserName = input("UserName: ")
            Password = input("Password: ")
            Role = input("Role: ")
            JoinDate = input("Join Date (YYYY-MM-DD): ")
            admin = Admin(AdminID, FirstName, LastName, Email, PhoneNumber, UserName, Password, Role, JoinDate)
            admin_service.register_admin(admin)
            print("Registration successful.")

        elif choice == '2':
            username = input("Username: ")
            password = input("Password: ")
            if authentication_service.authenticate_admin(username, password):
                print("Login successful.")
                handle_admin_actions()
            else:
                print("Login failed. Incorrect credentials.")

        elif choice == '3':
            break
        else:
            print("Invalid choice.")

def main():
    while True:
        print("\nWelcome to CarConnect Portal")
        print("1. Customer Section")
        print("2. Admin Section")
        print("3. Exit")

        user_choice = input("Enter your choice: ")

        if user_choice == '1':
            customer_workflow()
        elif user_choice == '2':
            admin_workflow()
        elif user_choice == '3':
            print("Exiting CarConnect. Goodbye.")
            break
        else:
            print("Invalid input.")

if __name__ == "__main__":
    main()
