import sys
sys.path.append(r"C:\Users\parve\Documents\CarConnect") 

import unittest
from Dao.AuthenticationService import AuthenticationService
from Dao.CustomerService import CustomerService
from Dao.VehicleService import VehicleService
from entity.Customer import Customer
from entity.Vehicle import Vehicle

class TestCarRentalSystem(unittest.TestCase):

    def setUp(self):
        self.auth_service = AuthenticationService()
        self.customer_service = CustomerService()
        self.vehicle_service = VehicleService()

    def test_customer_authentication_with_invalid_credentials(self):
        username = "afreen"
        password = "afreen123"
        self.assertFalse(self.auth_service.authenticate_customer(username, password))

    def test_updating_customer_information(self):
        customer = Customer(
            CustomerID=4,
            FirstName="Suganthi",
            LastName="MS",
            Email="sugan123@mail.com",
            PhoneNumber="9025309801",
            Address="Trichy",
            UserName="suganthi",
            Password="sugan123",
            RegistrationDate="2024-06-27"
        )
        self.assertTrue(self.customer_service.update_customer(customer))

    def test_adding_new_vehicle(self):
        vehicle = Vehicle(
            VehicleID=200,
            Model="Hyryder",
            Make="Toyota",
            Year=2023,
            Color="Blue",
            RegistrationNumber="TN45BC1294",
            Availability=1,
            DailyRate=220.00
        )
        self.assertTrue(self.vehicle_service.add_vehicle(vehicle))

    def test_updating_vehicle_details(self):
        vehicle = Vehicle(
            VehicleID=125,
            Model="Creta",
            Make="Hyundai",
            Year=2021,
            Color="Black",
            RegistrationNumber="TN48YY7865",
            Availability=1,
            DailyRate=150.00
        )
        self.assertTrue(self.vehicle_service.update_vehicle(vehicle))

    def test_getting_list_of_available_vehicles(self):
        available_vehicles = self.vehicle_service.get_available_vehicles()
        self.assertIsInstance(available_vehicles, list)

if __name__ == '__main__':
    unittest.main()
