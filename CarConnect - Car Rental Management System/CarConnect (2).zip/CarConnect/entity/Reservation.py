class Reservation:
    def __init__(self, ReservationID=None, CustomerID=None, VehicleID=None, StartDate=None,
                 EndDate=None, TotalCost=0.0, Status=None):
        self.__ReservationID = ReservationID
        self.__CustomerID = CustomerID
        self.__VehicleID = VehicleID
        self.__StartDate = StartDate
        self.__EndDate = EndDate
        self.__TotalCost = TotalCost
        self.__Status = Status

    def get_ReservationID(self):
        return self.__ReservationID

    def set_ReservationID(self, ReservationID):
        self.__ReservationID = ReservationID

    def get_CustomerID(self):
        return self.__CustomerID

    def set_CustomerID(self, CustomerID):
        self.__CustomerID = CustomerID

    def get_VehicleID(self):
        return self.__VehicleID

    def set_VehicleID(self, VehicleID):
        self.__VehicleID = VehicleID

    def get_StartDate(self):
        return self.__StartDate

    def set_StartDate(self, StartDate):
        self.__StartDate = StartDate

    def get_EndDate(self):
        return self.__EndDate

    def set_EndDate(self, EndDate):
        self.__EndDate = EndDate

    def get_TotalCost(self):
        return self.__TotalCost

    def set_TotalCost(self, TotalCost):
        self.__TotalCost = TotalCost

    def get_Status(self):
        return self.__Status

    def set_Status(self, Status):
        self.__Status = Status
