class Customer:
    def __init__(self, CustomerID=None, FirstName=None, LastName=None, Email=None, PhoneNumber=None,
                 Address=None, UserName=None, Password=None, RegistrationDate=None):
        self.__CustomerID = CustomerID
        self.__FirstName = FirstName
        self.__LastName = LastName
        self.__Email = Email
        self.__PhoneNumber = PhoneNumber
        self.__Address = Address
        self.__UserName = UserName
        self.__Password = Password
        self.__RegistrationDate = RegistrationDate

    def get_CustomerID(self):
        return self.__CustomerID

    def set_CustomerID(self, CustomerID):
        self.__CustomerID = CustomerID

    def get_FirstName(self):
        return self.__FirstName

    def set_FirstName(self, FirstName):
        self.__FirstName = FirstName

    def get_LastName(self):
        return self.__LastName

    def set_LastName(self, LastName):
        self.__LastName = LastName

    def get_Email(self):
        return self.__Email

    def set_Email(self, Email):
        self.__Email = Email

    def get_PhoneNumber(self):
        return self.__PhoneNumber

    def set_PhoneNumber(self, PhoneNumber):
        self.__PhoneNumber = PhoneNumber

    def get_Address(self):
        return self.__Address

    def set_Address(self, Address):
        self.__Address = Address

    def get_UserName(self):
        return self.__UserName

    def set_UserName(self, UserName):
        self.__UserName = UserName

    def get_Password(self):
        return self.__Password

    def set_Password(self, Password):
        self.__Password = Password

    def get_RegistrationDate(self):
        return self.__RegistrationDate

    def set_RegistrationDate(self, RegistrationDate):
        self.__RegistrationDate = RegistrationDate

        
