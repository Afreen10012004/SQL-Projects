class Vehicle:
    def __init__(self, VehicleID=None, Model=None, Make=None, Year=None, Color=None,
                 RegistrationNumber=None, Availability=True, DailyRate=0.0):
        self.__VehicleID= VehicleID
        self.__Model = Model
        self.__Make = Make
        self.__Year = Year
        self.__Color = Color
        self.__RegistrationNumber = RegistrationNumber
        self.__Availability = Availability
        self.__DailyRate = DailyRate

    def get_VehicleID(self):
        return self.__VehicleID

    def set_VehicleID(self, VehicleID):
        self.__VehicleID = VehicleID

    def get_Model(self):
        return self.__Model

    def set_Model(self, Model):
        self.__Model = Model

    def get_Make(self):
        return self.__Make

    def set_Make(self, Make):
        self.__Make = Make

    def get_Year(self):
        return self.__Year

    def set_Year(self, Year):
        self.__Year = Year

    def get_Color(self):
        return self.__Color

    def set_Color(self, Color):
        self.__Color = Color

    def get_RegistrationNumber(self):
        return self.__RegistrationNumber

    def set_RegistrationNumber(self, RegistrationNumber):
        self.__RegistrationNumber = RegistrationNumber

    def get_Availability(self):
        return self.__Availability

    def set_Availability(self, Availability):
        self.__Availability = Availability

    def get_DailyRate(self):
        return self.__DailyRate

    def set_DailyRate(self, DailyRate):
        self.__DailyRate = DailyRate

    def __str__(self):
        return f"VehicleID: {self.__VehicleID}, Model: {self.__Model}, Make: {self.__Make}, Year: {self.__Year}, Color: {self.__Color}, Reg#: {self.__RegistrationNumber}, Available: {self.__Availability}, Rate: {self.__DailyRate}"