class Admin:
    def __init__(self, AdminID, FirstName, LastName, Email, PhoneNumber, Username, Password, Role, JoinDate):
        self.__AdminID = AdminID
        self.__FirstName = FirstName
        self.__LastName = LastName
        self.__Email = Email
        self.__PhoneNumber = PhoneNumber
        self.__Username = Username
        self.__Password = Password
        self.__Role = Role
        self.__JoinDate = JoinDate

    def get_AdminID(self):
        return self.__AdminID

    def set_AdminID(self, AdminID):
        self.__AdminID = AdminID

    def get_FirstName(self):
        return self.__FirstName

    def set_FirstName(self, FirstName):
        self.__FirstName = FirstName

    def get_LastName(self):
        return self.__LastName

    def set_LastName(self, LastName):
        self.__LastName = LastName

    def get_Email(self):
        return self.__Email

    def set_Email(self, Email):
        self.__Email = Email

    def get_PhoneNumber(self):
        return self.__PhoneNumber

    def set_PhoneNumber(self, PhoneNumber):
        self.__PhoneNumber = PhoneNumber

    def get_Username(self):
        return self.__Username

    def set_Username(self, Username):
        self.__Username = Username

    def get_Password(self):
        return self.__Password

    def set_Password(self, Password):
        self.__Password = Password

    def get_Role(self):
        return self.__Role

    def set_Role(self, Role):
        self.__Role = Role

    def get_JoinDate(self):
        return self.__JoinDate

    def set_JoinDate(self, JoinDate):
        self.__JoinDate = JoinDate


    def __str__(self):
        return f"AdminID: {self.__AdminID}, Name: {self.__FirstName} {self.__LastName}, Email: {self.__Email}, Phone: {self.__PhoneNumber}, Username: {self.__Username}, Role: {self.__Role}, Join Date: {self.__JoinDate}"
