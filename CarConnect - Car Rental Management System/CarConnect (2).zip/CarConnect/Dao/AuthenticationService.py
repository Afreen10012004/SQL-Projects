import sys
sys.path.append(r"C:\Users\parve\Documents\CarConnect") 

from entity.Admin import Admin
from entity.Customer import Customer
from Dao.DatabaseContext import DatabaseContext
from exception.AdminNotFoundException import AdminNotFoundException
from exception.CustomerNotFoundException import CustomerNotFoundException

class AuthenticationService:

    def authenticate_admin(self, username, password):
        try:
            connection = DatabaseContext.getConnection(r'C:\Users\parve\Documents\CarConnect\util\db.properties')
            cursor = connection.cursor()

            cursor.execute("SELECT * FROM Admin WHERE UserName = ? AND Password = ?", (username, password))
            result = cursor.fetchone()

            if not result:
                raise AdminNotFoundException("Invalid admin credentials.")
                print("Admin login failed.")
                return None

            return Admin(*result)

        except Exception as e:
            print("Error during admin authentication:", e)
            return None

    def authenticate_customer(self, username, password):
        try:
            connection = DatabaseContext.getConnection(r'C:\Users\parve\Documents\CarConnect\util\db.properties')
            cursor = connection.cursor()

            cursor.execute("SELECT * FROM Customer WHERE UserName = ? AND Password = ?", (username, password))
            result = cursor.fetchone()

            if not result:
                raise CustomerNotFoundException("Invalid customer credentials.")
                print("Customer login failed.")
                return None

            return Customer(*result)

        except Exception as e:
            print("Error during customer authentication:", e)
            return None
