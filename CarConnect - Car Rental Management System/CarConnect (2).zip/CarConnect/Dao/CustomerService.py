import sys
sys.path.append(r"C:\Users\parve\Documents\CarConnect") 

from Dao.ICustomerService import ICustomerService
from entity.Customer import Customer
from util.DBConnUtil import DBConnUtil  

class CustomerService(ICustomerService):

    def register_customer(self, customer: Customer):
        try:
            connection = DBConnUtil.get_connection()
            cursor = connection.cursor()

            cursor.execute(
                "INSERT INTO Customer (CustomerID, FirstName, LastName, Email, PhoneNumber, Address, Username, Password, RegistrationDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (customer.get_CustomerID(), customer.get_FirstName(), customer.get_LastName(),
                 customer.get_Email(), customer.get_PhoneNumber(), customer.get_Address(),
                 customer.get_UserName(), customer.get_Password(), customer.get_RegistrationDate())
            )

            connection.commit()
            return True

        except Exception as e:
            print("Error registering customer:", e)
            return False

    def update_customer(self, customer: Customer):
        try:
            connection = DBConnUtil.get_connection()
            cursor = connection.cursor()

            cursor.execute(
                "UPDATE Customer SET FirstName=?, LastName=?, Email=?, PhoneNumber=?, Address=?, Username=?, Password=?, RegistrationDate=? WHERE CustomerID=?",
                (customer.get_FirstName(), customer.get_LastName(), customer.get_Email(),
                 customer.get_PhoneNumber(), customer.get_Address(), customer.get_UserName(),
                 customer.get_Password(), customer.get_RegistrationDate(), customer.get_CustomerID())
            )

            connection.commit()
            return True

        except Exception as e:
            print("Error updating customer:", e)
            return False

    def get_customer_by_id(self, customer_id):
        try:
            connection = DBConnUtil.get_connection()
            cursor = connection.cursor()

            cursor.execute("SELECT * FROM Customer WHERE CustomerID = ?", (customer_id,))
            data = cursor.fetchone()

            if data:
                return Customer(*data)
            else:
                return None

        except Exception as e:
            print("Error fetching customer by ID:", e)
            return None

    def get_customer_by_username(self, username):
        try:
            connection = DBConnUtil.get_connection()
            cursor = connection.cursor()

            cursor.execute("SELECT * FROM Customer WHERE Username = ?", (username,))
            data = cursor.fetchone()

            if data:
                return Customer(*data)
            else:
                return None

        except Exception as e:
            print("Error fetching customer by username:", e)
            return None

    def delete_customer(self, customer_id):
        try:
            connection = DBConnUtil.get_connection()
            cursor = connection.cursor()

            cursor.execute("DELETE FROM Customer WHERE CustomerID = ?", (customer_id,))
            connection.commit()

            return True

        except Exception as e:
            print("Error deleting customer:", e)
            return False
