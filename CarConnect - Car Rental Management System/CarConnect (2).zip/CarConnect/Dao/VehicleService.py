import sys
sys.path.append(r"C:\Users\parve\Documents\CarConnect") 

from Dao.IVehicleService import IVehicleService
from entity.Vehicle import Vehicle
from util.DBConnUtil import DBConnUtil

class VehicleService(IVehicleService):

    def get_vehicle_by_id(self, vehicle_id):
        connection = DBConnUtil.get_connection()
        cursor = connection.cursor()

        query = "SELECT * FROM Vehicle WHERE VehicleID = ?"
        cursor.execute(query, (vehicle_id,))
        row = cursor.fetchone()

        if row:
            vehicle = Vehicle(*row)
            return vehicle
        else:
            return None

    def get_available_vehicles(self):
        connection = DBConnUtil.get_connection()
        cursor = connection.cursor()

        query = "SELECT * FROM Vehicle WHERE Availability = 1"
        cursor.execute(query)
        vehicles = cursor.fetchall()

        result = []
        for row in vehicles:
            result.append(Vehicle(*row))

        return result

    def add_vehicle(self, vehicle: Vehicle):
        connection = DBConnUtil.get_connection()
        cursor = connection.cursor()

        query = """INSERT INTO Vehicle 
        (VehicleID, Model, Make, Year, Color, RegistrationNumber, Availability, DailyRate) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)"""
        
        cursor.execute(query, (
            vehicle.get_VehicleID(),
            vehicle.get_Model(),
            vehicle.get_Make(),
            vehicle.get_Year(),
            vehicle.get_Color(),
            vehicle.get_RegistrationNumber(),
            vehicle.get_Availability(),
            vehicle.get_DailyRate()
        ))

        connection.commit()
        return True

    def update_vehicle(self, vehicle: Vehicle):
        connection = DBConnUtil.get_connection()
        cursor = connection.cursor()

        query = """UPDATE Vehicle SET 
            Model = ?, 
            Make = ?, 
            Year = ?, 
            Color = ?, 
            RegistrationNumber = ?, 
            Availability = ?, 
            DailyRate = ? 
            WHERE VehicleID = ?"""

        cursor.execute(query, (
            vehicle.get_Model(),
            vehicle.get_Make(),
            vehicle.get_Year(),
            vehicle.get_Color(),
            vehicle.get_RegistrationNumber(),
            vehicle.get_Availability(),
            vehicle.get_DailyRate(),
            vehicle.get_VehicleID()
        ))

        connection.commit()
        return True

    def remove_vehicle(self, vehicle_id):
        connection = DBConnUtil.get_connection()
        cursor = connection.cursor()

        query = "DELETE FROM Vehicle WHERE VehicleID = ?"
        cursor.execute(query, (vehicle_id,))
        connection.commit()

        return True