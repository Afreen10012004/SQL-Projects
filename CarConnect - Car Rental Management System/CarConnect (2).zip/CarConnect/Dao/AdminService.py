import sys
sys.path.append(r"C:\Users\parve\Documents\CarConnect") 
from Dao.IAdminService import IAdminService
from entity.Admin import Admin
from Dao.DatabaseContext import DatabaseContext
from exception.AdminNotFoundException import AdminNotFoundException
from exception.InvalidInputException import InvalidInputException

class AdminService(IAdminService):

    def get_admin_by_id(self, admin_id):
        try:
            conn = DatabaseContext.getConnection("util/db.properties")
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Admin WHERE adminID = ?", (admin_id,))
            row = cursor.fetchone()
            if row:
                return Admin(*row)
            return None
        except Exception as e:
            print("Error:", e)
            return None

    def get_admin_by_username(self, username):
        try:
            conn = DatabaseContext.getConnection("util/db.properties")
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Admin WHERE username = ?", (username,))
            row = cursor.fetchone()
            if row:
                return Admin(*row)
            return None
        except Exception as e:
            print("Error:", e)
            return None

    def register_admin(self, admin: Admin):
        try:
            conn = DatabaseContext.getConnection("util/db.properties")
            cursor = conn.cursor()
            cursor.execute("INSERT INTO Admin VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", (
                admin.adminID, admin.firstName, admin.lastName, admin.email,
                admin.phoneNumber, admin.username, admin.password,
                admin.role, admin.joinDate
            ))
            conn.commit()
            return True
        except Exception as e:
            print("Error:", e)
            return False

    def update_admin(self, admin: Admin):
        try:
            conn = DatabaseContext.getConnection("util/db.properties")
            cursor = conn.cursor()
            cursor.execute("""UPDATE Admin SET firstName=?, lastName=?, email=?, phoneNumber=?, username=?, 
                            password=?, role=?, joinDate=? WHERE adminID=?""", (
                admin.firstName, admin.lastName, admin.email, admin.phoneNumber,
                admin.username, admin.password, admin.role, admin.joinDate, admin.adminID
            ))
            conn.commit()
            return True
        except Exception as e:
            print("Error:", e)
            return False

    def delete_admin(self, admin_id):
        try:
            conn = DatabaseContext.getConnection("util/db.properties")
            cursor = conn.cursor()
            cursor.execute("DELETE FROM Admin WHERE adminID=?", (admin_id,))
            conn.commit()
            return True
        except Exception as e:
            print("Error:", e)
            return False
