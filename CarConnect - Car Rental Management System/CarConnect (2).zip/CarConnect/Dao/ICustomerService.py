import sys
sys.path.append(r"C:\Users\parve\Documents\CarConnect")

from abc import ABC, abstractmethod
from entity.Customer import Customer

class ICustomerService(ABC):

    @abstractmethod
    def get_customer_by_id(self, customer_id):
        pass

    @abstractmethod
    def get_customer_by_username(self, username):
        pass

    @abstractmethod
    def register_customer(self, customer: Customer):
        pass

    @abstractmethod
    def update_customer(self, customer: Customer):
        pass

    @abstractmethod
    def delete_customer(self, customer_id):
        pass
