import sys
sys.path.append(r"C:\Users\parve\Documents\CarConnect") 

from Dao.IReservationService import IReservationService
from entity.Reservation import Reservation
from Dao.DatabaseContext import DatabaseContext
from exception.ReservationNotFoundException import ReservationNotFoundException
from exception.InvalidInputException import InvalidInputException

class ReservationService(IReservationService):

    def get_reservation_by_id(self, reservation_id):
        try:
            conn = DatabaseContext.getConnection("util/db.properties")
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Reservation WHERE reservationID = ?", (reservation_id,))
            row = cursor.fetchone()
            if row:
                return Reservation(*row)
            return None
        except Exception as e:
            print("Error:", e)
            return None

    def get_reservations_by_customer_id(self, customer_id):
        try:
            conn = DatabaseContext.getConnection("util/db.properties")
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Reservation WHERE customerID = ?", (customer_id,))
            rows = cursor.fetchall()
            return [Reservation(*row) for row in rows]
        except Exception as e:
            print("Error:", e)
            return []

    def create_reservation(self, reservation: Reservation):
        try:
            conn = DatabaseContext.getConnection("util/db.properties")
            cursor = conn.cursor()
            cursor.execute("""INSERT INTO Reservation 
                (reservationID, customerID, vehicleID, startDate, endDate, totalCost, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)""", (
                reservation.reservationID, reservation.customerID, reservation.vehicleID,
                reservation.startDate, reservation.endDate, reservation.totalCost, reservation.status
            ))
            conn.commit()
            return True
        except Exception as e:
            print("Error:", e)
            return False

    def update_reservation(self, reservation: Reservation):
        try:
            conn = DatabaseContext.getConnection("util/db.properties")
            cursor = conn.cursor()
            cursor.execute("""UPDATE Reservation SET customerID=?, vehicleID=?, startDate=?, endDate=?, 
                totalCost=?, status=? WHERE reservationID=?""", (
                reservation.customerID, reservation.vehicleID,
                reservation.startDate, reservation.endDate,
                reservation.totalCost, reservation.status,
                reservation.reservationID
            ))
            conn.commit()
            return True
        except Exception as e:
            print("Error:", e)
            return False

    def cancel_reservation(self, reservation_id):
        try:
            conn = DatabaseContext.getConnection("util/db.properties")
            cursor = conn.cursor()
            cursor.execute("DELETE FROM Reservation WHERE reservationID = ?", (reservation_id,))
            conn.commit()
            return True
        except Exception as e:
            print("Error:", e)
            return False
