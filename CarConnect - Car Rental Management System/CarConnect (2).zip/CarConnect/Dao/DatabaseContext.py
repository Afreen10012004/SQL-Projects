import sys
import pyodbc

sys.path.append(r"C:\Users\parve\Documents\CarConnect")  

from util.PropertyUtil import PropertyUtil

class DatabaseContext:
    @staticmethod
    def getConnection(property_file_path):
        try:
            connection_string = PropertyUtil.get_property_string()
            return pyodbc.connect(connection_string)
        except Exception as e:
            print("Database connection failed:", e)
            return None
